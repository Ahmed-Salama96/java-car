/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package overtake;

/**
 *
 * @author ahmed salama
 */
public class Radio {
     private boolean st;
    private int vol;
   int onR()
    {
        mediaPlayer s=new mediaPlayer();
        if(s.statue())
        {
            return 0;
        }
        st=true;
        vol=5;
        return 1;
    }
    void offR()
    {
        st=false;
        vol=0;
    }
    void increaseVol()
    {
        vol+=5;
    }
    void decreaseVol()
    {
        vol-=5;
        if(vol<=0)
        {
            st=false;
            vol=0;
            
        }
    }
    boolean state()
    {
        return st;
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package overtake;

/**
 *
 * @author ahmed salama
 */
public class mediaPlayer {
    private boolean st;
    private int vol;
   void on()
    {
        st=true;
        vol=5;
    }
    void off()
    {
        st=false;
        vol=0;
    }
    void incVol()
    {
        vol+=5;
    }
    void decVol()
    {
        vol-=5;
        if(vol<=0)
        {
            st=false;
            vol=0;
            
        }
    }
    boolean statue()
    {
        return st;
    }
}

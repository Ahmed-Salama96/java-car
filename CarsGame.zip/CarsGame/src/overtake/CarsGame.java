package overtake;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import static java.lang.String.format;
public class CarsGame extends JFrame {
    Car1 c1;                                                                           
    Car2 c2;                                                                       
    Car3 c3;         
    Tank t;
    int[] keyControls = {0,0,0,0};  
    Timer timer;                                                                            
    double timeRem;                                                                         
    int penaltyTime = 120;                                                                
    int gameEnd = 0;                                                                      
    public static void main(String[] args) {
       CarsGame s=new CarsGame();
       s.setVisible(true); 
    }
    public CarsGame() {
        Road road = new Road();                                                       
        c1 = new Car1();                                                                   
        c2 = new Car2();
        c3=new Car3();
        t=new Tank();
        add(road, BorderLayout.CENTER);                                                   
        setSize(600,720);                                                                 
        setTitle("car game _ahmed salama_ mohamed atito");   
        setLocationRelativeTo(null);                                                       
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);                                    
        setResizable(false);                                                               
        setVisible(true);                                                                 
        initialiseApp(); 
        
        class KeyChecker implements KeyListener {                                          
            @Override  
            public void keyPressed(KeyEvent e) {                                           
                if (e.getKeyCode() == KeyEvent.VK_LEFT) { keyControls[0] = 1; }               
                if (e.getKeyCode() == KeyEvent.VK_RIGHT) { keyControls[1] = 1; }            
                if (e.getKeyCode() == KeyEvent.VK_UP) { keyControls[2] = 1; }              
                if (e.getKeyCode() == KeyEvent.VK_DOWN) { keyControls[3] = 1; }             
                if (e.getKeyCode() == KeyEvent.VK_Y) { initialiseApp(); }                  
                if (e.getKeyCode() == KeyEvent.VK_N) { System.exit(0); }  
            } 

            @Override
            public void keyReleased(KeyEvent e) {                                          
                if (e.getKeyCode() == KeyEvent.VK_LEFT) { keyControls[0] = 0; }           
                if (e.getKeyCode() == KeyEvent.VK_RIGHT) { keyControls[1] = 0; }           
                if (e.getKeyCode() == KeyEvent.VK_UP) { keyControls[2] = 0; }             
                if (e.getKeyCode() == KeyEvent.VK_DOWN) { keyControls[3] = 0; }             
            }

            @Override
            public void keyTyped(KeyEvent e) {                                              
            }
        }
        KeyChecker keyListener = new KeyChecker();                                          
        addKeyListener(keyListener);                                                      
    }
           
    class Road extends JPanel {
    
        Image jcar1; 
        ImageIcon pngDriver = new ImageIcon(this.getClass().getResource("carb75.png"));
        Image jcar2;
        ImageIcon pngSlow = new ImageIcon(this.getClass().getResource("slow75.png"));
        Image jcar3;
        ImageIcon pngTruck = new ImageIcon(this.getClass().getResource("truck90.png"));
        Image bg;
        ImageIcon jpgBg = new ImageIcon(this.getClass().getResource("bg2.jpg"));
        Image fire;
        ImageIcon pngEx = new ImageIcon(this.getClass().getResource("explode.png"));
        Image again;
        ImageIcon jpgGo = new ImageIcon(this.getClass().getResource("go.jpg"));
        Image jtank;
        ImageIcon tank=new ImageIcon(this.getClass().getResource("tank.png")); 
        public Road() {                                                                    
            setDoubleBuffered(true);                                                       
            TimerListener animate = new TimerListener();                                   
            timer = new Timer(25,animate);                                                  
            timer.start();                                                                 
        }
        private class TimerListener implements ActionListener {                             
        @Override
            public void actionPerformed(ActionEvent e) {                                 
                if (timeRem > 0) timeRem--;                                              
                if (c1.hit > 0) {                                                         
                    penaltyTime--;      
                    if (penaltyTime == 0) {                                               
                        c1.hit = 0;
                        penaltyTime = 100;
                        c2.y = -200;
                        c2.setSpeed();
                        c3.setSpeed();
                        t.setSpeed();
                        c3.y = -c3.yStart;
                        c1.x = 195;
                        t.y=-100;
                    }
                }
                if (timeRem > 0 && c1.hit == 0) {                                         
                    c1.move(getHeight());       
                    c2.move(getHeight());
                    t.move(getHeight());   
                    c3.move(getHeight());         
                    c1.checkHit();                                                        
                }else if(timeRem>0&&c1.hit==-1)
                {
                    c1.move(getHeight());       
                    c2.move(getHeight());
                    t.move(getHeight());   
                    c3.move(getHeight());         
                    c1.checkHit(); 
                    c1.addGas();
                }
                else if (timeRem <= 0) {                                                 
                    gameEnd = 1;                                                           
                }
                repaint();                                                                
            }
        }
        @Override                                                         
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            jcar1 = pngDriver.getImage();
            jcar2 = pngSlow.getImage();
            jcar3 = pngTruck.getImage();
            bg = jpgBg.getImage();
            fire = pngEx.getImage();
            again = jpgGo.getImage();
            jtank=tank.getImage();
            g.drawImage(bg,0,0,getWidth()+1,getHeight(),this);  
            g.drawImage(jcar1, c1.x, c1.y, this);
            g.drawImage(jcar2, c2.x, (int) Math.round(c2.y), this);
            g.drawImage(jcar3, c3.x ,(int) Math.round(c3.y), this); 
            g.drawImage(jtank,t.x, (int)Math.round(t.y), this) ; 
            if (c1.hit == 1){ g.drawImage(fire, c1.x ,c1.y-20, this);gameEnd=1;}
            if (c1.hit == 2){ g.drawImage(fire, c1.x ,c1.y+130, this);gameEnd=1;}
           if(c1.hit==-1){c1.addGas();}
            if (gameEnd == 1) {
                g.drawImage(again, 157,250, this);
                g.setColor(Color.WHITE);                                                         
                g.setFont(new Font("Arial",Font.BOLD,26));                                     
                g.drawString("Your score: " + format("%.0f",c1.score), 190, 335);
                c2.speed=c3.speed=t.speed=0;
                c1.gear=0;
                timeRem=0;
            }
            g.setColor(Color.BLACK);                                                          
            g.fillRect(5,5,130,50);                                                           
            g.fillRect(getWidth()-125,5,120,50);                                             
            g.setColor(Color.WHITE);                                                           
            g.setFont(new Font("Consolas",Font.BOLD,16));                                      
            g.drawString(" GEAR : "+c1.gear, 10, 45 );                                            
            g.drawString(" SPEED: " + format("%.0f",c1.speed), 10, 25);                         
            g.drawString(" SCORE: "+ format("%.0f",c1.score), getWidth()-125, 25 );               
            g.drawString(" TIME to win: " + format("%.0f",timeRem), getWidth()-180, 45); 
            g.drawString("atito car in line", 10, 150 );                        
            g.drawString(" SPEED : " + format("%.2f",c2.speed), 10, 175);
            g.drawString(" Y-POS : " + format("%.2f",c2.y), 10, 200);
            g.drawString("salama truck", getWidth()-145, 150 );                        
            g.drawString(" SPEED : " + format("%.2f",c3.speed), getWidth()-145, 175);
            g.drawString(" Y-POS : " + c3.y, getWidth()-145, 200);
             g.drawString("gas amount: " + format("%.2f",c1.gas),5,500);
           }
    }
    class Car1 {                                                                                
        int gear = 1;                                                                        
        double acce = 0;
        int x;
        int y =0;
        double speed = 0;
        double score = 0;
        int hit = 0;
          double gas=0;      
        public Car1() {}                                                                      
        public void addGas(){gas=1000;}
        public void useGase(){
            gas-=5;
            if(gas<=0){gas=0;gameEnd=1;}
        }
        public void move(int height) {                                                         
            if (speed > 0) {
                if (x < 330 && keyControls[1] == 1) {x+=6;useGase();}     
                if (x > 195 && keyControls[0] == 1){ x-=6;useGase();}
                 if ((x < 330||x>195) && keyControls[2] == 1) {useGase();}
            }
            gearCheck();                                                                        
            speed+=acce;                                                                       
            if (speed > 100) speed = 100;                                                      
            if (speed < 0) speed = 0;                                                         
            score += (speed/100);                                                              
            y = height-200;
            
        }
        public void gearCheck() {                                                              
            if (gear == 1 && speed > 20) gear = 2;                                                   
            if (gear == 2 && speed > 40) gear = 3;                                             
            if (gear == 3 && speed > 70) gear = 4;
            if (gear == 4 && speed < 60) gear = 3;
            if (gear == 3 && speed < 40) gear = 2;
            if (gear == 2 && speed < 20) gear = 1;
            if (keyControls[2] == 1) acce = (5 - (gear/2.0))/2.0;                            
            if (keyControls[3] == 1)  acce = (-(5-gear));                                     
            if (keyControls[2] == 0 && keyControls[3] == 0) acce = -0.05;                     
        }

        public void checkHit() {                                                               
            if (x < c2.x + 65) {                                                          
                if (y > c2.y + 140 || y < c2.y - 150){ hit = 0; }
                else {
                    if (y < c2.y + 45) hit = 2; 
                    else hit = 1;
                    speed = 0;
                    c2.speed = 0;
                }}
             if (x +65 > c3.x) {                                                        
                if (y > c3.y + 190 || y < c3.y - 170) hit = 0; 
                else {
                    hit = 1;
                    speed = 0;
                    c3.speed = 0;
                }}
         
        }}
    class Car2 {                                             
        int x = 195;
        double y;
        double speed;
        double yStart = 200;
        
        public Car2() {                                                                      
            setSpeed();
            this.y = -yStart;
        }
        
        public void move(int height) {                                                         
           y += (c1.speed - speed)/10.0;                                                    
  if (y >= height + yStart) {
                y = -yStart;
                setSpeed();
            }
            if (y < -yStart) {
                y = height + yStart;
                setSpeed();
            }
        }
    public void setSpeed() {                                                              
            speed = 40+ Math.random() * 20;
        }
    }
    class Tank{                                                                           
        int x = 325;                                                                          
        int y = 0;
        double speed;
        int yStart = 300;
public Tank() {                                                                
            setSpeed(); 
            this.y = -300;
        }
        public void move(int height) {                                                          
           
            y += (c1.speed + speed)/20.0;                                                     
           
            if (y > (height + yStart)) {
                y = -yStart - (int)(Math.random()*(yStart/10))-10;                                
                setSpeed();
            }
            if (y < -yStart) {
                y = height + yStart-10;
                setSpeed();
            }
    }
          public void setSpeed() {                                                              
            speed=c1.speed;
            if(speed<0)speed=0; 
            y = -yStart;
        }}    
       class Car3 {                                                                       
        int x = 325;                                                                           
        int y = 0;
        double speed;
        int yStart = 300;
public Car3() {                                                                 
            setSpeed(); 
            this.y = -300;
        }
 public void move(int height) {                                                         
          y += (c1.speed + speed)/20.0;
            if (y > (height + yStart)) {
                y = -yStart - (int)(Math.random()*(yStart/2))-10;                                
                setSpeed();
            }
            if (y < -yStart) {
                y = height + yStart-10;
                setSpeed();
            }
        }

        public void setSpeed() {                                                            
            speed = 20 + (Math.random()*20.0);
            y = -yStart;
        }    
    }
    public void initialiseApp() {                                                             
        timeRem =3000;                                                                 
        c1.x = 220;                   
        penaltyTime = 100;
        c2.yStart = 200;
        c3.yStart = 300;
        t.yStart=50;
        c2.y = c2.yStart;
        c3.y = c3.yStart;
        gameEnd = 0;
        c1.score = 0;
        c1.speed = 0;
        c1.gas=4000;
        c2.setSpeed();
        c3.setSpeed();
    }
}
